import {works} from './collection.js';
import {team} from './team.js';
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;
const positions=[
 [570,53,172,-9,.62],[430,7,650,10,.42],[440,63,700,13,.54],[380,30,1010,-12,.35],[310,73,1165,12,.6],
 [330,5,1120,-8,.45],[280,38,615,-16,.32],[300,15,1430,10,.65],[300,47,1490,-8,.45],[270,76,1460,16,.3]
];
let activePreview=null,previewTimer,previewSession=null;
function attachVideo(video,work,onError){let hls=null;video.poster='.'+work.poster;const url='.'+work.video;if(video.canPlayType('application/vnd.apple.mpegurl')){video.src=url;video.load();}else if(window.Hls?.isSupported()){hls=new Hls({maxBufferLength:12,maxMaxBufferLength:20,backBufferLength:0,startLevel:0});hls.loadSource(url);hls.attachMedia(video);hls.on(Hls.Events.ERROR,(_,data)=>{if(data.fatal)onError?.();});}else onError?.();return{destroy(){hls?.destroy();video.pause();video.removeAttribute('src');video.load();}};}
function stopPreview(){clearTimeout(previewTimer);if(activePreview){const v=activePreview.querySelector('video');v.pause();activePreview.classList.remove('previewing');}previewSession?.destroy?.();previewSession=null;activePreview=null;}
function opticMarkup(work,index){
 const [w,x,y,r,rest]=positions[index];
 const ticks=Array.from({length:48},(_,i)=>{const major=i%4===0;return `<path d="M300 ${major?24:28}V${major?35:33}" transform="rotate(${i*7.5} 300 170)"/>`;}).join('');
 return `<button type="button" class="optic" data-id="${work.id}" aria-label="睁眼观看：${work.zh}" aria-haspopup="dialog" style="--w:${w}px;--x:${x}%;--y:${y}px;--r:${r}deg;--rest:${rest};--opening:${rest*50}%;--delay:${-index*1.6}s;--duration:${9+index%4}s"><span class="optic-drift"><span class="optic-stage"><svg class="optic-structure" viewBox="0 0 600 340" aria-hidden="true"><defs><linearGradient id="metal-${index}" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#565656"/><stop offset=".3" stop-color="#a8a8a8"/><stop offset=".56" stop-color="#fafafa"/><stop offset=".82" stop-color="#747474"/><stop offset="1" stop-color="#bcbcbc"/></linearGradient></defs><g class="iris-rings" fill="none" stroke="url(#metal-${index})"><circle cx="300" cy="170" r="140"/><circle cx="300" cy="170" r="131"/><circle cx="300" cy="170" r="120"/><circle cx="300" cy="170" r="114"/></g><g class="iris-ticks" fill="none" stroke="#999999">${ticks}</g><g class="eye-lids" fill="none" stroke="url(#metal-${index})"><path class="upper-lid" d="M22 170C108 147 178 39 300 42S482 142 578 170"/><path class="lower-lid" d="M22 170C112 193 189 298 300 298S488 196 578 170"/></g><g class="corner-marks" stroke="#8c8c8c" fill="none"><path d="M10 170H45M555 170H590M300 12V22M300 318V328"/></g></svg><span class="iris-well"><span class="iris-mask"><img class="iris-cover" src=".${work.poster}" alt="" draggable="false" ${index>3?'loading="lazy"':''}><video class="optic-video" muted playsinline loop preload="none" aria-hidden="true" tabindex="-1"></video><span class="iris-glass" aria-hidden="true"></span></span></span><span class="eye-highlight" aria-hidden="true"></span><span class="optic-number" aria-hidden="true">${work.number}</span><span class="optic-action" aria-hidden="true">VIEW FILM ↗</span></span><span class="optic-label"><span>${work.zh}</span><small>${work.durationLabel} / ${work.title}</small></span></span></button>`;
}
$('#optics').innerHTML=works.map(opticMarkup).join('');
$$('.optic').forEach((el,index)=>{
 const wake=()=>{el.classList.add('is-open');if(!matchMedia('(hover: hover)').matches||reduce)return;stopPreview();activePreview=el;previewTimer=setTimeout(()=>{if(activePreview!==el||$$('dialog[open]').length)return;const v=el.querySelector('video');v.muted=true;previewSession=attachVideo(v,works[index]);v.addEventListener('playing',()=>{if(activePreview===el)el.classList.add('previewing');},{once:true});v.play().catch(()=>{});},450);};
 const sleep=()=>{el.classList.remove('is-open');el.style.setProperty('--look-x','0px');el.style.setProperty('--look-y','0px');if(activePreview===el)stopPreview();};
 let pointerFrame=0,point=null;
 el.addEventListener('pointermove',e=>{if(reduce||e.pointerType==='touch')return;point=[e.clientX,e.clientY];if(pointerFrame)return;pointerFrame=requestAnimationFrame(()=>{pointerFrame=0;const r=el.getBoundingClientRect();el.style.setProperty('--look-x',`${(point[0]-r.left-r.width/2)/r.width*8}px`);el.style.setProperty('--look-y',`${(point[1]-r.top-r.height/2)/r.height*6}px`);});},{passive:true});
 el.addEventListener('pointerenter',e=>{if(e.pointerType!=='touch')wake();});el.addEventListener('pointerleave',sleep);el.addEventListener('focus',wake);el.addEventListener('blur',sleep);el.addEventListener('click',()=>openFilm(works[index].id));
});
const motifs=[`<circle cx="100" cy="100" r="68"/><ellipse cx="100" cy="100" rx="25" ry="68"/><ellipse cx="100" cy="100" rx="50" ry="68"/><path d="M34 75H166M34 125H166M32 100H168"/>`,`<path d="M30 55 75 30 125 55 170 30V145L125 170 75 145 30 170ZM75 30V145M125 55V170M30 95 75 70 125 95 170 70"/>`,`<circle cx="100" cy="100" r="58"/><circle cx="80" cy="88" r="45"/><circle cx="120" cy="88" r="45"/><circle cx="100" cy="122" r="45"/>`,`<path d="M100 28 162 64 162 136 100 172 38 136 38 64Z M38 64 100 100 162 64M100 100V172M100 28V100M38 136 100 100 162 136"/>`,`<circle cx="100" cy="100" r="62"/><ellipse cx="100" cy="100" rx="80" ry="23" transform="rotate(-35 100 100)"/><ellipse cx="100" cy="100" rx="80" ry="23" transform="rotate(35 100 100)"/><circle cx="100" cy="100" r="8"/>`,`<path d="M40 135Q40 35 100 35T160 135Q100 195 40 135ZM50 132Q100 50 150 132M65 142Q100 80 135 142M82 150Q100 110 118 150"/>`,`<path d="M100 25V175M25 100H175M47 47 153 153M47 153 153 47M73 30 127 170M30 73 170 127M30 127 170 73M73 170 127 30"/><circle cx="100" cy="100" r="42"/>`];
$('#team-grid').innerHTML=motifs.map((m,i)=>`<article class="team-card"><button type="button" class="team-portrait" data-member="${i}" aria-label="查看第${i+1}位成员个人详情" aria-haspopup="dialog"><svg viewBox="0 0 200 200" fill="none" stroke="#747474" stroke-width=".85" aria-hidden="true">${m}</svg><small>VIEW PROFILE ↗</small></button><span class="team-no">PERSPECTIVE / 0${i+1}</span><div class="team-name"><h3>成员姓名待补充</h3><small>LIANGMA</small></div><p class="team-role">职务 / 创作分工待补充</p></article>`).join('')+`<div class="team-join"><span aria-hidden="true">↗</span><p>每一种视角，<br>都让想象更完整。</p><small>SEVEN MINDS. MANY POSSIBILITIES.</small></div>`;
const viewer=$('#viewer'),video=$('#main-video');let current=-1,mainSession=null,lastFocus=null,closeTimer;
function lock(){document.body.classList.add('locked');}function unlock(){if(!$$('dialog[open]').length)document.body.classList.remove('locked');}
function openFilm(id,updateUrl=true){const i=works.findIndex(w=>w.id===id);if(i<0)return;stopPreview();if($('#index-dialog').open)$('#index-dialog').close();const wasOpen=viewer.open;if(!wasOpen)lastFocus=document.activeElement;mainSession?.destroy();video.pause();current=i;const w=works[i];$('#viewer-title').textContent=w.zh;$('#viewer-en').textContent=w.title;$('#viewer-duration').textContent=w.durationLabel;$('#viewer-desc').textContent=w.description;$('#work-count').textContent=`${w.number} / 10`;$('#project-notes').hidden=true;$('#show-notes').setAttribute('aria-expanded','false');$('#project-notes').innerHTML=`<p>${w.note}</p><p>${w.process}</p><p>类型 / ${({brand:'品牌影像',product:'产品视觉',art:'艺术短片'})[w.group]} · 影片时长 / ${w.durationLabel}</p>`;$('#play-main').hidden=false;$('#video-status').textContent='';$('#previous-work').disabled=i===0;$('#next-work').disabled=i===works.length-1;video.muted=false;video.loop=false;mainSession=attachVideo(video,w,()=>{$('#video-status').textContent='影片暂未加载成功，请重新点击播放或稍后再试。';$('#play-main').hidden=false;});if(!viewer.open){viewer.showModal();lock();}if(updateUrl)history.pushState({film:id},'',`#film/${id}`);}
function closeFilm(restoreHash=true){if(!viewer.open)return;mainSession?.destroy();mainSession=null;viewer.close();viewer.classList.remove('expanded');$('#expand-window').setAttribute('aria-pressed','false');$('#expand-window').setAttribute('aria-label','放大作品小窗');unlock();if(restoreHash&&location.hash.startsWith('#film/'))history.replaceState(null,'','#top');lastFocus?.focus({preventScroll:true});}
$('#close-viewer').addEventListener('click',()=>closeFilm());viewer.addEventListener('cancel',e=>{e.preventDefault();closeFilm();});$('#play-main').addEventListener('click',()=>{if(video.error){mainSession?.destroy();mainSession=attachVideo(video,works[current]);}$('#video-status').textContent='正在加载影片…';video.play().then(()=>{$('#play-main').hidden=true;$('#video-status').textContent='';}).catch(()=>{$('#video-status').textContent='暂未能播放，请再试一次。';});});video.addEventListener('playing',()=>{$('#play-main').hidden=true;$('#video-status').textContent='';});$('#expand-window').addEventListener('click',()=>{const expanded=viewer.classList.toggle('expanded');$('#expand-window').setAttribute('aria-pressed',expanded);$('#expand-window').setAttribute('aria-label',expanded?'还原作品小窗':'放大作品小窗');});$('#previous-work').addEventListener('click',()=>{if(current>0)openFilm(works[current-1].id);});$('#next-work').addEventListener('click',()=>{if(current<works.length-1)openFilm(works[current+1].id);});$('#show-notes').addEventListener('click',()=>{const p=$('#project-notes');p.hidden=!p.hidden;$('#show-notes').setAttribute('aria-expanded',!p.hidden);if(!p.hidden)p.scrollIntoView({block:'nearest',behavior:reduce?'instant':'smooth'});});$('#open-company').addEventListener('click',()=>{closeFilm(false);history.pushState(null,'','#studio');$('#studio').scrollIntoView({behavior:reduce?'instant':'smooth'});});function toast(message){$('#toast').textContent=message;$('#toast').classList.add('visible');clearTimeout(closeTimer);closeTimer=setTimeout(()=>$('#toast').classList.remove('visible'),3500);}$('#share-work').addEventListener('click',async()=>{try{await navigator.clipboard.writeText(location.href);toast('作品链接已复制，可以分享给朋友。');}catch{toast('请复制浏览器地址栏中的作品链接。');}});
function renderIndex(filter='all'){$('#index-list').innerHTML=works.filter(w=>filter==='all'||w.group===filter).map(w=>`<button class="index-row" data-work="${w.id}" aria-label="在小窗打开${w.zh}"><span>${w.number}</span><img src=".${w.poster}" alt=""><div><b>${w.zh}</b><small>${w.title}</small></div><span>${w.durationLabel}</span><span>↗</span></button>`).join('');$$('.index-row').forEach(el=>el.addEventListener('click',()=>openFilm(el.dataset.work)));}
renderIndex();$('#open-index').addEventListener('click',()=>{$('#index-dialog').showModal();lock();});$('#close-index').addEventListener('click',()=>{$('#index-dialog').close();unlock();});$$('[data-filter]').forEach(b=>b.addEventListener('click',()=>{$$('[data-filter]').forEach(x=>x.setAttribute('aria-pressed',x===b));renderIndex(b.dataset.filter);}));$('#index-dialog').addEventListener('close',unlock);
const contactDialog=$('#contact-dialog');function contact(kind){const wechat=kind==='wechat';$('#contact-dialog-title').textContent=wechat?'先打个招呼。':'你的想法，从这里开始。';$('#contact-dialog-copy').innerHTML=wechat?`<p>欢迎与量孖聊聊新的创作与合作。</p><div class="placeholder-box">微信二维码 / 微信号<br><small>正式联系方式待补充</small></div><small>微信、邮箱与正式合作信息待补充。</small>`:`<p>一个项目、一段影像，或一个还未成形的念头。</p><div class="brief-directions"><span>品牌宣传</span><span>产品视觉</span><span>艺术短片</span><span>其他想法</span></div><p>合作时可以准备：项目方向、观看场景、时间计划、预算范围、已有素材与期待的表达。</p><div class="placeholder-box">项目联系邮箱 / 微信<br><small>正式联系方式待补充</small></div><small>本预览尚未接入提交或发送服务。</small>`;contactDialog.showModal();lock();}$('#contact-wechat').addEventListener('click',()=>contact('wechat'));$('#contact-brief').addEventListener('click',()=>contact('brief'));$('#close-contact').addEventListener('click',()=>{contactDialog.close();unlock();});contactDialog.addEventListener('close',unlock);
// Preserve native scrolling; let the optical field fade gently into the team section.
let scrollScheduled=false;
function updateScroll(){scrollScheduled=false;const hero=$('.hero'),height=hero.offsetHeight,y=scrollY;const p=Math.max(0,Math.min(1,(y-height*.68)/(height*.42)));hero.style.setProperty('--optic-opacity',1-p);hero.style.setProperty('--optic-shift',`${-p*35}px`);}
window.addEventListener('scroll',()=>{if(!scrollScheduled){scrollScheduled=true;requestAnimationFrame(updateScroll);}if(activePreview&&scrollY>$('.hero').offsetHeight-120)stopPreview();},{passive:true});
window.addEventListener('pointermove',e=>{if(reduce||scrollY>innerHeight||e.pointerType==='touch')return;$('.surface').style.setProperty('--px',e.clientX/innerWidth-.5);$('.surface').style.setProperty('--py',e.clientY/innerHeight-.5);},{passive:true});
document.addEventListener('visibilitychange',()=>{if(document.hidden){stopPreview();video.pause();}});
window.addEventListener('popstate',()=>{if(location.hash.startsWith('#film/'))openFilm(location.hash.slice(6),false);else closeFilm(false);});
window.addEventListener('hashchange',()=>{if(location.hash.startsWith('#film/'))openFilm(location.hash.slice(6),false);});
if(location.hash.startsWith('#film/'))openFilm(decodeURIComponent(location.hash.slice(6)),false);
updateScroll();

// Member data and copy mirror 111; company films remain explicitly labelled demo material.
const memberDialog=$('#member-dialog'),memberVideo=$('#member-video');
let selectedMember=null,memberPortfolio=[],memberWorkIndex=0,memberSession=null,memberOrigin=null;
function selectMemberWork(index){
 if(index<0||index>=memberPortfolio.length)return;
 memberSession?.destroy();memberSession=null;memberWorkIndex=index;
 const work=memberPortfolio[index];
 $('#member-work-title').textContent=work.zh;$('#member-work-duration').textContent=work.durationLabel;
 $('#member-work-count').textContent=`${String(index+1).padStart(2,'0')} / ${String(memberPortfolio.length).padStart(2,'0')}`;
 $('#play-member').hidden=false;$('#member-video-status').textContent='';
 $$('.member-work').forEach((button,i)=>button.setAttribute('aria-pressed',i===index));
 memberVideo.muted=false;memberVideo.loop=false;
 memberSession=attachVideo(memberVideo,work,()=>{$('#member-video-status').textContent='影片暂不可用，请切换另一部作品。';$('#play-member').hidden=false;});
}
function openMember(index,origin){
 stopPreview();selectedMember=team[index];memberOrigin=origin;
 const member=selectedMember;
 $('#member-number').textContent=`MEMBER ${String(index+1).padStart(2,'0')} / LIANGMA`;
 $('#member-name').textContent=member.name||'成员姓名待补充';
 $('#member-role').textContent=member.role||'职务 / 分工待补充';
 $('#member-bio').textContent=member.bio||'个人介绍待补充。这里将展示成员的创作经历、关注方向，以及在项目中承担的具体工作。';
 $('#member-symbol').innerHTML=motifs[index];
 memberPortfolio=member.workIds?.length?member.workIds.map(id=>works.find(w=>w.id===id)).filter(Boolean):works.slice(0,5);
 $('#member-demo-note').hidden=!!member.workIds?.length;
 $('#member-work-list').innerHTML=memberPortfolio.map((work,i)=>`<button class="member-work" type="button" data-member-work="${i}" aria-label="预览成员作品${work.zh}" aria-pressed="${i===0}"><img src=".${work.poster}" alt="${work.zh}封面" loading="lazy" draggable="false"><small>${work.zh}</small></button>`).join('');
 $$('.member-work').forEach(button=>button.addEventListener('click',()=>selectMemberWork(Number(button.dataset.memberWork))));
 memberDialog.showModal();lock();$('#member-work-list').scrollLeft=0;$('.member-body').scrollTop=0;selectMemberWork(0);
}
function closeMember(){if(!memberDialog.open)return;memberSession?.destroy();memberSession=null;memberDialog.close();unlock();memberOrigin?.focus({preventScroll:true});}
$$('[data-member]').forEach(button=>button.addEventListener('click',()=>openMember(Number(button.dataset.member),button)));
$('#close-member').addEventListener('click',closeMember);
memberDialog.addEventListener('cancel',event=>{event.preventDefault();closeMember();});
$('#play-member').addEventListener('click',()=>{
 if(memberVideo.error)selectMemberWork(memberWorkIndex);
 $('#member-video-status').textContent='正在加载影片…';
 memberVideo.play().then(()=>{$('#play-member').hidden=true;$('#member-video-status').textContent='';}).catch(()=>{$('#member-video-status').textContent='暂未能播放，请再试一次。';});
});
memberVideo.addEventListener('playing',()=>{$('#play-member').hidden=true;$('#member-video-status').textContent='';});
$('#member-previous').addEventListener('click',()=>$('#member-work-list').scrollBy({left:-270,behavior:reduce?'instant':'smooth'}));
$('#member-next').addEventListener('click',()=>$('#member-work-list').scrollBy({left:270,behavior:reduce?'instant':'smooth'}));
document.addEventListener('visibilitychange',()=>{if(document.hidden)memberVideo.pause();});
