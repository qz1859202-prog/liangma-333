// Replace only supplied member details; the seven empty entries are layout slots.
export const team=Array.from({length:7},(_,index)=>({id:`member-${index+1}`,name:'',role:'',photo:''}));
